diamonds-data
=============

This is the diamonds data from 2014 referenced in a recent blogpost:
http://solomonmessing.wordpress.com/2014/01/19/visualization-series-the-scatterplot-or-how-to-use-data-so-you-dont-get-ripped-off/
